package com.example.folhapagamento2

class Funcionario (var nome: String, var valorHora: Float, var horasTrab: Int) {

    var salBruto : Float
    var ir: Float
    var inss : Float
    var fgts : Float
    var salLiquido : Float

    init {
        salBruto = valorHora * horasTrab
        if (salBruto <= 1372.81f) {
            ir = 0.0f
        } else if (salBruto <= 2743.25f) {
            ir = salBruto * 0.15f
        } else {
            ir = salBruto * 0.275f
        }

        if (salBruto <= 868.29f) {
            inss = salBruto * 0.08f
        } else if (salBruto <= 1447.14f) {
            inss = salBruto * 0.09f
        } else if (salBruto <= 2894.28f) {
            inss = salBruto * 0.11f
        } else {
            inss = 318.37f
        }

        fgts = salBruto * 0.08f

        salLiquido = salBruto - ir - inss
    }


    override fun toString(): String {
        return "DADOS DO FUNCIONÁRIO\n" +
                "Funcionário: $nome\n" +
                "Valor da hora: R$ $valorHora\n" +
                "Horas trabalhadas: $horasTrab h\n" +
                "Salário Bruto: R$ $salBruto \n" +
                "Calculo do IR: $ir \n" +
                "INSS: $inss \n" +
                "FGTS: $fgts \n" +
                "Salário Liquido $salLiquido"
    }
}