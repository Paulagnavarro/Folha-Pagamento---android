package com.example.folhapagamento

class Funcionario (var nome: String, var valorHora: Float, var horasTrab: Int, var cargo : String) {

    var salBruto : Float
    var abono : Float
    var salLiquido : Float

    init {
        salBruto = valorHora * horasTrab

        if(salBruto < 1500) {
            abono = salBruto * 0.2f
        } else if(salBruto <= 3000){
            abono = salBruto * 0.15f
        } else {
            abono = salBruto * 0.01f
        }

        salLiquido = salBruto + abono

        salBruto = String.format("%.2f", salBruto).toFloat()
        abono = String.format("%.2f", abono).toFloat()
        salLiquido = String.format("%.2f", salLiquido).toFloat()
    }

    override fun toString(): String {
        return "DADOS DO FUNCIONÁRIO\n" +
                "Funcionário: $nome\n" +
                "Valor da hora: R$ $valorHora\n" +
                "Horas trabalhadas: $horasTrab h\n" +
                "Cargo: $cargo \n" +
                "Salário Bruto: R$ $salBruto \n" +
                "Abono: $abono \n" +
                "Salário Liquido: $salLiquido"
    }
}